'use_strict';



// POP UP
/**
 * popup actions
 * 
 */
const close_popup = () => {
    const popup = document.getElementById('popup');
    popup.style.display = 'none';
};

const open_popup = () => {
    const popup = document.getElementById('popup');
    popup.style.display = 'block';
};

/**
 * allow to close popup clicking outsite of popup box and without clicking on close popup button
 */
document.getElementById('popup').addEventListener('click', (e) => {
    close_popup();
})
document.querySelectorAll('.popup .box')[0].addEventListener('click', (e) => {
    e.stopPropagation();
})

/**
 * close popup when clicking on close popup button
 */

const closeButton = document.getElementById('close-bttn');

closeButton.addEventListener('click', e => {
    close_popup();
});

// END POP UP


/**
 * Serch engine 
 * get input value filter and render results
 */
document.getElementById('search').addEventListener("keyup", function (e) {
    let searchTerm = e.target.value;
    let searchResuls = searchFunction(searchTerm);
    renderSearchResults(searchResuls);
});

/**
 *  populate #user-list div with search results 
 * @param users 
 * @returns 
 */
const renderSearchResults = (users) => {

    if (users.length === 0) return;

    const container = document.getElementById('user-list');
    container.innerHTML = ''; // Clear previous content

    for (let index = 0; index < users.length; index++) {
        const element = users[index];
        const userHTML = userItemTemplate(getUserById(element));
        container.innerHTML += userHTML;
    }

}
/**
 * get and filter results from database
 * @param par 
 * @returns array 
 */
const searchFunction = (par) => {
    let foundKeys = [];
    for (const key in db.users) {
        if (db.users[key].name.toLowerCase().includes(par)) {
            foundKeys.push(key);
        }
    }
    return foundKeys;
}


/**
 * click event listener 
 */
document.addEventListener("click", function (e) {
    e.preventDefault();



    const currentClicked = e.target.closest('a'); // find closest A tag 
    if (!currentClicked) return;


    const currentClickedClass = currentClicked.getAttribute('class'); // get element class attribute
    const currentClickedId = currentClicked.getAttribute('data-id'); // get element data-id attribute

    // run function depending on currentClickedClass value
    switch (currentClickedClass) {
        case 'del':
            deleteItem(currentClickedId);
            break;
        case 'info':
            infoItem(currentClickedId);
            break;
        case 'edit':
            editItem(currentClickedId);
            break;
        case 'add-new':
            addNew();
            break;
        case 'del-all':
            deleteAll();
            break;

        default:
            break;
    }

});

/**
 * CLear database update counter and render results
 */
const deleteAll = () => {
    db.users = {};
    updateCounter(getCount(db.users));
    renderUsers(getUsers());
}

/**
 * Delete spesific item by parameter id 
 * update counter
 * remove element from DOM
 * @param id 
 */
const deleteItem = (id) => {
    let elementToDelete = document.getElementById(id);
    if (elementToDelete) {
        elementToDelete.remove();
        delete db.users[id];
    }
    if (document.querySelectorAll('.items .item').length == 0) {
        document.querySelectorAll('.items')[0].innerHTML = userItemTemplateEmpty();
    }
    updateCounter(getCount(db.users));
}

/**
 * populate popup with info template and item data
 * @param  id 
 */
const infoItem = (id) => {
    const user = getUserById(id);
    const popup = document.getElementById('popup-content');
    popup.innerHTML = popupTemplate({ type: 'info', data: user });

    runCallbacks({
        open_popup
    });
}

/**
 * open popup and populate with edit form
 * @param  id 
 */
const editItem = (id) => {
    const user = getUserById(id);
    const popup = document.getElementById('popup-content');
    popup.innerHTML = popupTemplate({ type: 'edit', data: user });

    runCallbacks({
        open_popup,
    });
}

/**
 * open popup and populate with add-new form
 */
const addNew = () => {
    const popup = document.getElementById('popup-content');
    popup.innerHTML = popupTemplate({ type: 'add' });
    runCallbacks({
        open_popup,
    });

};


/**
 * submit event listener
 */

document.addEventListener("submit", function (e) {
    e.preventDefault();


    const formType = document.getElementById('form-type'); // get form type add-new or edit

    /**
     * input values
     */
    let name = document.getElementById('name');
    let phone = document.getElementById('phone');
    let address = document.getElementById('address');
    let age = document.getElementById('age');
    let image_url = document.getElementById('image_url');
    let id = document.getElementById('item-id');

    let itemData = {};

    /**
     * basic validation
     */
    if (!validation({ name, phone, address, age, image_url })) {
        return false;
    }


    if (formType.value === "add-new") {
        itemData.id = generateId(5);
    } else {
        itemData.id = id.value;
    }

    /**
     * map input values and add to itemData object
     */

    itemData.name = name.value;
    itemData.phone = phone.value;
    itemData.address = address.value;
    itemData.age = age.value;
    itemData.image_url = image_url.value;



    switch (formType.value) {
        case 'edit':
            updateItem(itemData)
            break;
        case 'add-new':
            createItem(itemData)
            break;
        default:
            break;
    }

    updateCounter(getCount(db.users));
    runCallbacks({ close_popup });

});


/**
 * add new item to database and render results
 * @param  data 
 */
const createItem = data => {
    db.users = Object.assign({ [data.id]: data }, db.users)
    renderUsers(getUsers());
};

/**
 * update spesific item and render results
 * @param data 
 */

const updateItem = data => {


    db.users[data.id].name = data.name;
    db.users[data.id].address = data.address;
    db.users[data.id].age = data.age;
    db.users[data.id].image_url = data.image_url;
    db.users[data.id].phone = data.phone;

    renderUsers(getUsers());
    runCallbacks({ close_popup })

};




