'use_strict';

const message = (name, age) => {
    const hname = name;
    const hage = age;
    return hname + ' is ' + hage + 'years old.';
};

export default message;